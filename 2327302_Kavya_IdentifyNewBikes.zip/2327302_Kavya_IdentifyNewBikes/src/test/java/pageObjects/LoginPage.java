package pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import factory.BaseClass;
import utilities.DataWriter;

public class LoginPage extends BasePage{
	public Actions action;
	public String error;
	public List<String> emailList;
	public List<String> errorList=new ArrayList<String>();

	
	//Constructor
	public LoginPage(WebDriver driver) {
		super(driver);
		action = new Actions(driver);
	}
	
	
	//Locators
		@FindBy(xpath = "//*[@id='des_lIcon']")
		WebElement LogIn;
		
		@FindBy(xpath = "//span[@class='lgn-sp s ggle']")
		WebElement GoogleBtn;
		
		@FindBy(xpath = "//input[@type='email']")
		WebElement Email;
		
		@FindBy(xpath = "//*[@id='identifierNext']/div/button/span")
		WebElement NextBtn;
		
		@FindBy(xpath = "//div[@class='Ekjuhf Jj6Lae']")
		WebElement errorMsg;
		
		
		//Action Methods
		public void clickLogInButton() {
			LogIn.click();
			BaseClass.waitMethod(GoogleBtn);
			
		}
		public void clickGoogleBtn() {
			GoogleBtn.click();
		}
		public void switchTowindow() {
		Set<String> windowids=driver.getWindowHandles();
		List<String> windowid=new ArrayList<String>(windowids);
		String childid=windowid.get(1);
		driver.switchTo().window(childid);
		}
		
		public void setEmail() throws InterruptedException {
			emailList = new ArrayList<>();
			emailList.add(BaseClass.randomeString() + "@gmail.com");
			emailList.add(BaseClass.randomeString()+"@xyz");
			emailList.add("");
			for(String email:emailList) {
				System.out.println(email);
				Email.sendKeys(email);
				BaseClass.waitMethod(NextBtn);
				NextBtn.click();
				BaseClass.waitMethod(errorMsg);
				error=errorMsg.getText();
				errorList.add(error);
				System.out.println(error);
				Email.clear();
			}
			
		}
		public void errorMessage() {
			List<String> headers = Arrays.asList("EmailIds", "Error Message");
		    try {
		        DataWriter.putData(emailList, 0, "Account Details", headers);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		    try {
		        DataWriter.putData(errorList, 1, "Account Details", headers);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }

		    
			System.out.println(errorList);
		}
}
