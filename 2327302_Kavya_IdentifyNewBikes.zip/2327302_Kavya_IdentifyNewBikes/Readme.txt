Identify New Bikes

Problem Statement : Identify New Bikes
==========================================================================================
Display upcoming bikes details like , bike name, its price and expected launch date in India
1. Manufacturer should be Honda.
2. Bike price should be less than 4Lac
(Suggested site: zigwheels however you are free to use any legitimate site)

Detailed Description: Hackath Ideas
============================================================================================
1. Display "Upcoming" bikes details like bike name, price and expected launch date in India, for manufacturer 'Honda' & Bike price should be less than 4Lac.
2. For Used cars in Chennai, extract all the popular models in a List; Display the same
3. Try to 'Login' with google, give invalid account details & capture the error message
(Suggested site: zigwheels.com however you are free to use any legitimate site)

Key Automation Scope
==============================================================================================
Handling windows & frames
Filling simple form, Capture warning message
Extract menu items from frames & store in collections
Navigating back to home page

Console Output
=============================================================================================
@regression
Scenario: View upcoming Honda bikes under 4Lac on ZigWheels                             # Features/UpcomingHondaBikes.feature:7
  Given the user is on the ZigWheels website                                            # stepDefinitions.UpcomingHondaBikes.the_user_is_on_the_zig_wheels_website()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 789342 bytes]

  When the user hovers over the New Bikes section                                       # stepDefinitions.UpcomingHondaBikes.the_user_hovers_over_the_section()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 711266 bytes]

  And the user selects Upcoming Bikes from the dropdown                                 # stepDefinitions.UpcomingHondaBikes.the_user_selects_upcoming_bikes_from_the_dropdown()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 292983 bytes]

  And the user sets the filter Manufacturer to Honda                                    # stepDefinitions.UpcomingHondaBikes.the_user_sets_the_filter_manufacturer_to_honda()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 121067 bytes]

  And the user clicks on the View More button                                           # stepDefinitions.UpcomingHondaBikes.the_user_clicks_on_the_view_more_button()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 384230 bytes]

[Honda PCX160, Rs. 1.20 Lakh, Expected Launch : Jun 2024]
[Honda Activa Electric, Rs. 1.10 Lakh, Expected Launch : Jun 2024]
[Honda Activa 7G, Rs. 79,000, Expected Launch : Oct 2024]
[Honda CB350 Cruiser, Rs. 2.30 Lakh, Expected Launch : Nov 2024]
[Honda Forza 350, Rs. 3.70 Lakh, Expected Launch : Unrevealed]
[Honda CBR150R, Rs. 1.70 Lakh, Expected Launch : Unrevealed]
[Honda Rebel 300, Rs. 2.30 Lakh, Expected Launch : Unrevealed]
[Honda CRF300L, Rs. 3.30 Lakh, Expected Launch Date : 31 Dec 2050]
  Then the user should filter out the displayed Honda bikes with a price less than 4Lac # stepDefinitions.UpcomingHondaBikes.the_user_should_filter_out_the_displayed_honda_bikes_with_a_price_less_than_4lac()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 232936 bytes]

Bike Name List: [Honda PCX160, Honda Activa Electric, Honda Activa 7G, Honda CB350 Cruiser, Honda Forza 350, Honda CBR150R, Honda Rebel 300, Honda CRF300L]
Price List: [Rs. 1.20 Lakh, Rs. 1.10 Lakh, Rs. 79,000, Rs. 2.30 Lakh, Rs. 3.70 Lakh, Rs. 1.70 Lakh, Rs. 2.30 Lakh, Rs. 3.30 Lakh]
Expected Launch Date List: [Jun 2024, Jun 2024, Oct 2024, Nov 2024, Unrevealed, Unrevealed, Unrevealed, 31 Dec 2050]
  And for each bike priced under 4Lac should be added to their respective lists         # stepDefinitions.UpcomingHondaBikes.for_each_bike_priced_under_4lac_should_be_added_to_their_respective_lists()

    Embedding ViewupcomingHondabikesunder4LaconZigWheels_Success [image/png 234159 bytes]


@sanity
Scenario: View popular used car models in Chennai                # Features/UsedCars.feature:7
  Given the user has the car sales website open in their browser # stepDefinitions.UsedCars.the_user_has_the_car_sales_website_open_in_their_browser()

    Embedding ViewpopularusedcarmodelsinChennai_Success [image/png 772332 bytes]

  When the user hovers over the Used Cars link                   # stepDefinitions.UsedCars.the_user_hovers_over_the_used_cars_link()

    Embedding ViewpopularusedcarmodelsinChennai_Success [image/png 608769 bytes]

  And the user selects Chennai from the dropdown                 # stepDefinitions.UsedCars.the_user_selects_chennai_from_the_dropdown()

    Embedding ViewpopularusedcarmodelsinChennai_Success [image/png 248315 bytes]

  And the user scrolls down to the list of popular models        # stepDefinitions.UsedCars.the_user_scrolls_down_to_the_list_of_popular_models()

    Embedding ViewpopularusedcarmodelsinChennai_Success [image/png 300926 bytes]

Maruti 800
Maruti Swift Dzire
Maruti Swift
Hyundai I10
Hyundai Santro Xing
Honda City
Toyota Innova
Toyota Fortuner
Mahindra XUV500
  Then the user should extract all the popular models in a List  # stepDefinitions.UsedCars.the_user_should_extract_all_the_popular_models_in_a_list()

    Embedding ViewpopularusedcarmodelsinChennai_Success [image/png 572549 bytes]

[Maruti 800, Maruti Swift Dzire, Maruti Swift, Hyundai I10, Hyundai Santro Xing, Honda City, Toyota Innova, Toyota Fortuner, Mahindra XUV500]
  And the user displays the same in the console                  # stepDefinitions.UsedCars.the_user_displays_the_same_in_the_console()

    Embedding ViewpopularusedcarmodelsinChennai_Success [image/png 540295 bytes]


@regression
Scenario: Login with invalid Google account details                           # Features/ZigWheelsLogin.feature:4
  Given the user has the car sales website open in their browser              # stepDefinitions.UsedCars.the_user_has_the_car_sales_website_open_in_their_browser()

    Embedding LoginwithinvalidGoogleaccountdetails_Success [image/png 789784 bytes]

  When the user clicks on the login icon                                      # stepDefinitions.LoginSteps.the_user_clicks_on_the_login_icon()

    Embedding LoginwithinvalidGoogleaccountdetails_Success [image/png 425648 bytes]

  And the user clicks on the Google button                                    # stepDefinitions.LoginSteps.the_user_clicks_on_the_google_button()

    Embedding LoginwithinvalidGoogleaccountdetails_Success [image/png 411003 bytes]

  And the user switches to the new window                                     # stepDefinitions.LoginSteps.the_user_switches_to_the_new_window()

    Embedding LoginwithinvalidGoogleaccountdetails_Success [image/png 58816 bytes]

bVsWT@gmail.com
Couldn’t find your Google Account
jOWmn@xyz
Enter a valid email or phone number

Enter an email or phone number
  And the user enters the emailId and clicks on the Next button               # stepDefinitions.LoginSteps.the_user_enters_the_email_id_and_clicks_on_the_next_button()

    Embedding LoginwithinvalidGoogleaccountdetails_Success [image/png 61943 bytes]

[Couldn’t find your Google Account, Enter a valid email or phone number, Enter an email or phone number]
  Then the system should display an error message and print it in the console # stepDefinitions.LoginSteps.the_system_should_display_an_error_message_and_print_it_in_the_console()

    Embedding LoginwithinvalidGoogleaccountdetails_Success [image/png 61943 bytes]

PASSED: io.cucumber.testng.AbstractTestNGCucumberTests.runScenario("Login with invalid Google account details", "Google Login")
        Runs Cucumber Scenarios
┌──────────────────────────────────────────────────────────────────────────┐
│ View your Cucumber Report at:                                            │
│ https://reports.cucumber.io/reports/3eefdaaa-9021-410a-a855-3a6a363f7e74 │
│                                                                          │
│ This report will self-destruct in 24h.                                   │
│ Keep reports forever: https://reports.cucumber.io/profile                │
└──────────────────────────────────────────────────────────────────────────┘PASSED: io.cucumber.testng.AbstractTestNGCucumberTests.runScenario("View upcoming Honda bikes under 4Lac on ZigWheels", "Display upcoming Honda bikes under 4Lac in India on ZigWheels")
        Runs Cucumber Scenarios
PASSED: io.cucumber.testng.AbstractTestNGCucumberTests.runScenario("View popular used car models in Chennai", "Display popular used car models in Chennai")
        Runs Cucumber Scenarios

===============================================
    Default test
    Tests run: 1, Failures: 0, Skips: 0
===============================================


===============================================
Default suite
Total tests run: 3, Passes: 3, Failures: 0, Skips: 0
===============================================

Dependencies
========================================================================================
  <!-- https://mvnrepository.com/artifact/commons-io/commons-io -->
<dependency>
    <groupId>commons-io</groupId>
    <artifactId>commons-io</artifactId>
    <version>2.15.1</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.apache.commons/commons-lang3 -->
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-lang3</artifactId>
    <version>3.14.0</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java -->
<dependency>
    <groupId>org.seleniumhq.selenium</groupId>
    <artifactId>selenium-java</artifactId>
    <version>4.18.1</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.testng/testng -->
<dependency>
    <groupId>org.testng</groupId>
    <artifactId>testng</artifactId>
    <version>7.9.0</version>
    <scope>test</scope>
</dependency>

<!-- https://mvnrepository.com/artifact/org.apache.poi/poi -->
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi</artifactId>
    <version>5.2.5</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.apache.poi/poi-ooxml -->
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-ooxml</artifactId>
    <version>5.2.5</version>
</dependency>
<!-- https://mvnrepository.com/artifact/com.aventstack/extentreports -->
<dependency>
    <groupId>com.aventstack</groupId>
    <artifactId>extentreports</artifactId>
    <version>5.1.1</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-api -->
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-api</artifactId>
    <version>3.0.0-beta2</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-core -->
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-core</artifactId>
    <version>3.0.0-beta2</version>
</dependency>
<!-- https://mvnrepository.com/artifact/io.cucumber/cucumber-java -->
<dependency>
    <groupId>io.cucumber</groupId>
    <artifactId>cucumber-java</artifactId>
    <version>7.16.1</version>
</dependency>
<!-- https://mvnrepository.com/artifact/io.cucumber/cucumber-junit -->
<dependency>
    <groupId>io.cucumber</groupId>
    <artifactId>cucumber-junit</artifactId>
    <version>7.16.1</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>io.cucumber</groupId>
    <artifactId>cucumber-testng</artifactId>
    <version>7.16.1</version>
    <scope>test</scope>
</dependency>
<!-- https://mvnrepository.com/artifact/com.aventstack/extentreports-cucumber4-adapter -->
	<dependency>
	    <groupId>tech.grasshopper</groupId>
	    <artifactId>extentreports-cucumber7-adapter</artifactId>
	    <version>1.14.0</version>
	</dependency>
</dependencies>
<pluginManagement>
  <plugins>
  <plugin>
          <groupId>org.apache.maven.plugins</groupId>
          <artifactId>maven-compiler-plugin</artifactId>
          <version>3.13.0</version>
        </plugin>
        <plugin>
          <groupId>org.apache.maven.plugins</groupId>
          <artifactId>maven-surefire-plugin</artifactId>
          <version>3.2.5</version>
          <configuration>
          <suiteXmlFiles>
          <suiteXmlFile>testng.xml</suiteXmlFile>
          </suiteXmlFiles>
          </configuration>
        </plugin>
  </plugins>
  </pluginManagement>
  
The Tools and Technology
================================================================================================
Cucumber
Selenium
Page Object Model [POM] with PageFactory
Apache poi[MS Excel]
ExtentReports


